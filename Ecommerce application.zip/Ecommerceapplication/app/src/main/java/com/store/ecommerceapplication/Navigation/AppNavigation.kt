package com.store.ecommerceapplication.Navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.store.ecommerceapplication.Presentation.Auth.ForgotPasswordScreen
import com.store.ecommerceapplication.Presentation.Auth.LoginScreen
import com.store.ecommerceapplication.Presentation.Auth.SignupScreen
import com.store.ecommerceapplication.Presentation.AuthenticationViewModel.AuthenticationViewModel
import com.store.ecommerceapplication.Presentation.OnboardingScreen.FristInterScreen
import com.store.ecommerceapplication.Presentation.OnboardingScreen.SecondInterScreen
import com.store.ecommerceapplication.Presentation.OnboardingScreen.ThirdInterScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.OnboardingScreen1) {
        composable<Routes.LoginScreen> {
            LoginScreen(navController)
        }

        composable<Routes.SignUpScreen> {
            SignupScreen(
                navController,
                viewModel = AuthenticationViewModel()
            )
        }

        composable<Routes.ForgetPasswordScreen> {
            ForgotPasswordScreen(navController)
        }

        composable<Routes.OnboardingScreen1> {
            FristInterScreen(navController)

        }

        composable<Routes.OnboardingScreen2> {
            SecondInterScreen(navController)
        }

        composable<Routes.OnboardingScreen3> {
            ThirdInterScreen(navController)

        }


    }
}